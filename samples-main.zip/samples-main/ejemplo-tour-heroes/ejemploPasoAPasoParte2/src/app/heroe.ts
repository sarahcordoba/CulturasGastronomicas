export interface Heroe {
    id:number,
    name:string,
    description:string
}

export const HEROES:Heroe[] = [
    {
    id : 1,
    name : 'Superman',
    description: "Clark Ken oculta sus poderes en un tímido e introvertido periodista..."
    },
    {
    id : 2,
    name : 'Batman',
    description: "Bruce Wills el  multimillonario oculta su temor a los murcipeplagos en un disfraz..."
    },
    {
    id : 3,
    name : 'Supergirl',
    description: 'Las mujeres tienen a su super man femenino...'
    }
  ]