export interface Heroe {
    id:number,
    name:string
}
