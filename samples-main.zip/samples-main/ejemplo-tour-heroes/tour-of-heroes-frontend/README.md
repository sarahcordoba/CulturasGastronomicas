# Ejemplo Frontend Ángular Tour de Héroes

Es el mismo ejemplo del tutorial oficial de Angular <https://angular.io/tutorial/tour-of-heroes> con algunas modificaciones:
- Se deshabilitó la simulación del backend en memoria
- Se ajustó la URL de los servicios backend para usar el proyecto demo backend

Para ejecutar instale ángular y ejecute este comando:
```ng serve```

- Pruebe el frontend y al tiempo verifique en Mongo.
- Analice el código fuente
